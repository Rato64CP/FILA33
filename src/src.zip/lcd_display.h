// lcd_display.h
#pragma once

void inicijalizirajLCD();
void prikaziSat();
void prikaziPostavke();
