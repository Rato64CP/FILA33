// otkucavanje.h
#pragma once

void upravljajOtkucavanjem();
void otkucajSate(int broj);
void otkucajPolasata();
