// okretna_ploca.h
#pragma once

void inicijalizirajPlocu();
void upravljajPločom();
void postaviTrenutniPolozajPloce(int pozicija);
void postaviOffsetMinuta(int offset);
int dohvatiTrenutnuPozicijuPloce();
int dohvatiOffsetMinuta();
void pomakniPlocuZa(int brojKvadranata);
void kompenzirajPlocu();
