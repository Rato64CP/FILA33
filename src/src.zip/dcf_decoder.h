// dcf_decoder.h
#pragma once

void inicijalizirajDCF();
void dekodirajDCFSignal();
