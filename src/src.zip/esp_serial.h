// esp_serial.h
#pragma once

void inicijalizirajESP();
void obradiESPSerijskuKomunikaciju();
