// tipke.h
#pragma once

void inicijalizirajTipke();
void provjeriTipke();
bool uPostavkama();
