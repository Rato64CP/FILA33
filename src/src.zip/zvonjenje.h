// zvonjenje.h
#pragma once

void inicijalizirajZvona();
void upravljajZvonom();
void zapocniSlavljenje();
void zapocniMrtvacko();
void zaustaviZvonjenje();
